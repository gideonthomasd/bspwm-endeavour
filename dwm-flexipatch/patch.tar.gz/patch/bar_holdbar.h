static void keyrelease(XEvent *e);
static void holdbar(const Arg *arg);

