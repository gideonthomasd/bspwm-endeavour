static void tile(Monitor *);

