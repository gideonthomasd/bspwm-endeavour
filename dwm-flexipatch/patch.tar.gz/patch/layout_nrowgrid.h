static void nrowgrid(Monitor *m);

