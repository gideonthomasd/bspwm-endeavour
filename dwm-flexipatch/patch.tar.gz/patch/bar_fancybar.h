static int width_fancybar(Bar *bar, BarArg *a);
static int draw_fancybar(Bar *bar, BarArg *a);
static int click_fancybar(Bar *bar, Arg *arg, BarArg *a);

