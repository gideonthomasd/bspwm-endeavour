#!/bin/sh

cat <<EOF | xmenu
[]= Tiled Layout	0
><> Floating Layout	1
[M] Monocle Layout	2
EOF

