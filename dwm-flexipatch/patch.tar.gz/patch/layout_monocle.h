static void monocle(Monitor *m);

